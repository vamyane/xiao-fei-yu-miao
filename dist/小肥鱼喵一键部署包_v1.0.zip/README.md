# 小肥鱼喵 · 一键部署包（Windows）

把「DSH + SnowLuma + qq-bridge + 媒体工具 + 桌面控制台」一键装好的小白安装包。
用户只需要准备：**Windows 电脑 + QQ 小号 + DeepSeek API Key**。

## 包内有什么

```
小肥鱼喵一键部署包/
├─ 小肥鱼喵一键部署.exe      ← 双击这个（带界面的安装器）
├─ deploy.ps1                ← 安装核心逻辑（安装器调用，也可命令行运行）
├─ Installer.cs              ← 安装器源码（可自行编译）
├─ payload/
│   ├─ qq-bridge/            ← 桥接源码（MIT License，可直接分发）
│   ├─ app/                  ← 小肥鱼喵控制台（exe + 前端 + 后端）
│   ├─ patches/              ← 媒体工具 / 预设 / 安全守卫补丁
│   ├─ tools/7zr.exe         ← 解压 ComfyUI 用（LGPL）
│   ├─ config.template.json  ← 配置模板（安装时填充）
│   ├─ start-all.template.ps1 / stop-all.template.ps1 / start-comfyui.template.ps1
│   └─ docs/                 ← 小白教程 + 给 AI 的安装指令
└─ README.md
```

## 自动化边界（重要）

| 组件 | 谁来装 | 原因 |
| --- | --- | --- |
| qq-bridge 桥接 | ✅ 安装器自动（MIT，随包分发） | 开源可分发 |
| 小肥鱼喵控制台 | ✅ 安装器自动 | 自研 |
| 媒体工具（画图/语音/发图） | ✅ 安装器自动 | 自研 |
| Node.js / ffmpeg | ✅ 安装器自动（缺失时下载/便携化） | MIT/LGPL |
| ComfyUI 画图 | ✅ 可选自动（官方包 + 国内镜像） | GPL，官方渠道下载 |
| **DSH** | ❌ 用户自行安装 | 闭源商业软件，不可再分发 |
| **SnowLuma** | ❌ 用户自行下载/运行/扫码 | EULA 禁止第三方打包与自动化部署 |
| QQ 号扫码登录 | ❌ 用户手动 | 账号安全 |
| DeepSeek API Key | ❌ 用户购买并填入 DSH | 账号安全 |

> 这就是为什么不能做成“一个 exe 全包含”的完全零操作版：不是技术限制，是 DSH 与 SnowLuma 的许可限制。

## 用户操作流程（3 步人工 + 1 次自动部署）

1. 从官方安装 **DSH**，完成初始化。
2. 从 GitHub Releases 下载 **SnowLuma**，解压运行 `launcher.bat`，浏览器里扫码登录小号，开启 OneBot WS(3001)+HTTP(3000)。
3. 双击 **小肥鱼喵一键部署.exe**，在界面填：API Key、主号 QQ、安装目录，勾选两个“已就绪”，点开始。
4. 部署完成后打开 **小肥鱼喵** App 验收；API Key 已自动复制，去 DSH 设置粘贴即可。

## 给 AI Agent 用

部署完成后，把 `安装目录\docs\给AI的安装指令.md` 整段发给用户的 DSH Agent，让 AI 自动验收、修端口、补 ComfyUI、排错。

## 命令行用法（进阶）

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\deploy.ps1 `
  -InstallDir "D:\qq-bridge" -MainQQ 123456789 -BotQQ 987654321 `
  -SnowLumaDir "D:\SnowLuma" [-WithComfyUI] [-DryRun]
```

- `-DryRun`：只检查环境与依赖，不写入、不安装。
- 日志：安装器同目录 `install.log`。

## 许可与风险

- qq-bridge：MIT License（Copyright (c) 2026 Derpyu520 and qq-bridge / QSH contributors）。
- 7zr：GNU LGPL。
- Node.js：MIT。ComfyUI：GPL-3.0（从官方 release 下载）。
- **DSH 是闭源商业软件**，本包不包含、不修改，仅检测与配置。
- **SnowLuma 为第三方组件**，其 EULA 禁止并入第三方安装包/自动化部署；本包要求用户自行安装与启动，仅检测端口。
- 第三方协议端登录 QQ 存在风控/封号风险，请使用小号，并遵守 QQ 用户协议。

## 已知限制

- 安装器需要联网（会走 npmmirror / ghproxy / hf-mirror 镜像）。
- DSH 首次初始化/登录、SnowLuma 扫码必须人工完成。
- 如果目标机已装旧版，安装器会保留现有 `config.json` 与数据，只补缺失文件。
